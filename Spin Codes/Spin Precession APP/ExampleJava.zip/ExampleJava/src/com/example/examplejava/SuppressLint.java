package com.example.examplejava;

public @interface SuppressLint {

	int value();

}
